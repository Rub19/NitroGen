import random, string, requests
f=open("Valid Nitro.txt", "w", encoding='utf-8')
print("""      
 _   _   _                                               _
| \ | (_) |                                             | |            
|  \| |_| |_ _ __ ___     __ _  ___ _ __   ___ _ __ __ _| |_ ___  _ __ 
| . ` | | __| '__/ _ \   / _` |/ _ \ '_ \ / _ \ '__/ _` | __/ _ \| '__|
| |\  | | |_| | | (_) | | (_| |  __/ | | |  __/ | | (_| | || (_) | |   
\_| \_/_|\__|_|  \___/   \__, |\___|_| |_|\___|_|  \__,_|\__\___/|_|   
                          __/ |                                        
                         |___/                                         """)

print('                          Made by Rub19#0001')
input("Press Enter to continue...")

 
while True:
    code = ('').join(random.choices(string.ascii_letters + string.digits, k=16))
    r = requests.get(f"https://discordapp.com/api/v8/entitlements/gift-codes/{code}?with_application=false&with_subscription_plan=true")
    if r.status_code == 200:
        print(f"Valid Nitro Code > discord.gift/{code}")
        f.write(f"discord.gift/{code}\n")
    else:
        print(f"Invalid Nitro Code > discord.gift/{code}")    